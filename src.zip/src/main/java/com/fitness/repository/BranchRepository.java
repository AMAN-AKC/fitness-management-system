package com.fitness.repository;

import com.fitness.entity.Branch;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface BranchRepository extends JpaRepository<Branch, Long> {
	List<Branch> findByIsActiveTrue();

	boolean existsByBranchName(String branchName);

	java.util.Optional<Branch> findByBranchNameIgnoreCase(String branchName);
}